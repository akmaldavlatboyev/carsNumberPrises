from run_app import*


def main():
    runApp()

if __name__ == "__main__":
    main()






           



